<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Exemplo em CodeIgniter</title>
  </head>
  <body>
    <h1><?php echo $titulo; ?></h1>
