<div class="">
  <h1><?= $titulo; ?></h1>
  <p> Primeira aplicação com CI. </p>
  <p>ADS - <?= $ano; ?></p>
</div>
